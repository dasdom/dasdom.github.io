#!/usr/bin/bash

files=$(ls);

for file in $files
do
    date_string=$(grep '^date:' $file | cut -d ' ' -f 2)
    mv "$file" "$date_string-$file"
done
